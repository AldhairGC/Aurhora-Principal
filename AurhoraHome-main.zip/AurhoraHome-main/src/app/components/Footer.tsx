import React from "react";
import Link from "next/link";

const Footer = () => {
  return (
    <footer className="bg-black text-gray-500 py-10 border-t border-gray-700">
      <div className="container mx-auto px-6 text-center md:flex md:justify-between md:items-center">
        <div className="mb-4 md:mb-0">
          <Link href="/" className="text-xl font-extrabold">
            <span className="bg-gradient-to-r from-teal-400 via-fuchsia-500 to-lime-400 bg-clip-text text-transparent opacity-80">
              Aurhora
            </span>{" "}
            <span className="text-gray-300">Agency</span>
          </Link>
          <p className="text-xs mt-1">
            © 2025 Aurhora Agency. Todos los derechos reservados.
          </p>
        </div>

        <div className="flex justify-center items-center space-x-6">
          <Link
            href="/politica-privacidad"
            className="text-xs text-gray-400 hover:text-white transition duration-300"
          >
            Política de Privacidad
          </Link>
          <a
            href="https://linkedin.com/company/aurhora-agency"
            target="_blank"
            rel="noopener noreferrer"
            title="LinkedIn"
            className="text-gray-400 hover:text-white transition duration-300"
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
              <path
                fillRule="evenodd"
                d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.79-1.75-1.764s.784-1.764 1.75-1.764 1.75.79 1.75 1.764-.783 1.764-1.75 1.764zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z"
                clipRule="evenodd"
              />
            </svg>
          </a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
